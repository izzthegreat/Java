public class Wolf extends Canine{
    Wolf(String gender,int age){
        super(gender, age);
        this.adultAt = 2;
    }
}
