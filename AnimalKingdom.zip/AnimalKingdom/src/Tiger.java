class Tiger extends Panther {
    Tiger(String gender,int age){
        super(gender, age);
        this.adultAt = 5;
    }
}
