abstract class Pongo extends GreatApe{
    Pongo(String gender,int age){
        super(gender, age);
    }
}
