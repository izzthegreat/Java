abstract class Vertibrate extends Animal{
    Vertibrate(String gender, int age){
        super(gender, age);
    }
}
