abstract class Pan extends GreatApe {
        Pan(String gender ,int age){
            super(gender, age);
        }
}
