class Lion extends Panther {
    Lion(String gender,int age){
        super(gender, age);
        this.adultAt = 3;
    }
}
