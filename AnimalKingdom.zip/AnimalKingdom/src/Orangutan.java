class Orangutan extends Pongo {
    Orangutan(String gender,int age){
        super(gender, age);
        adultAt = 8;
    }
}
