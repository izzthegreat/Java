abstract class Homo extends GreatApe {
    Homo(String gender,int age){
        super(gender, age);
    }
}
