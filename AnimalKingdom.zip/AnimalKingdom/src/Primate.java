abstract class Primate extends Mammal {
    Primate(String gender,int age){
        super(gender, age);
    }
    void thumbsUp(){
        System.out.println("\uD83D\uDC4D");
    }
}
