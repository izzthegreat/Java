public class Chimpanzee extends Pan {
    Chimpanzee(String gender, int age) {
        super(gender, age);
        adultAt = 9;
    }
}
