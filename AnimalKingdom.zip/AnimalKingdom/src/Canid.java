abstract class Canid extends Carnivore {
    Canid(String gender,int age){
        super(gender, age);
    }
}
