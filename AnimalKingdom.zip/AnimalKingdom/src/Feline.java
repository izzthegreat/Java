abstract class Feline extends Carnivore{
    Feline(String gender,int age){
        super(gender, age);
    }
}
