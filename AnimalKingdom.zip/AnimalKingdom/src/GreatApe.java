abstract class GreatApe extends Primate {
    GreatApe(String gender,int age){
        super(gender, age);
    }
}
